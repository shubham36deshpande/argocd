# Changelog

All notable changes to the image will be documented in this file.

## [11.16-patch.0] - 2022-06-14

### Added

- Initial release of Dockerfile with PostgreSQL version `11.16`

[11.16-patch.0]: https://github.com/airflow-helm/charts/tree/images/postgresql-bitnami/11/alpine-11.16-patch.0/images/postgresql-bitnami/11/alpine